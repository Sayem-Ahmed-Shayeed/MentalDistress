# Phase 6 `Others` Sensitivity Report

## Material Passport

- Sources: manifest-verified frozen Phase 4 and Phase 5 result tables.
- Statistical units: model seed for original analysis; model-seed/bootstrap-replicate for resampling analysis.
- Scope: six unordered pairs among Suicidal, Depressed, Anxious, and Frustrated.
- Phase mapping: operational Phase 6, corresponding to original master-plan Phase 7.
- Verification: source manifests, schemas, counts, ranks, frequencies, frozen-H equality, output manifest, and deterministic ZIP.
- Test access: false. No models, raw text, prediction ZIPs, GPU, or network were used.
- Limitation: this sensitivity analysis changes the ranking universe but preserves BCR denominators; it does not redefine H.

## Main results

- Leading original named boundary: `Suicidal|Depressed` (mean BCR 0.078162).
- Leading restricted-bootstrap boundary: `Suicidal|Depressed` (mean seed top-3 frequency 1.0000).
- Kendall's W across original six-pair rankings: 0.934857.
- Mean named-pair error share: 0.4137.
- Mean `Others`-involving error share: 0.5863.

## Frozen-H audit

Frozen H contains 2 `Others`-involving pair(s) out of 3.

- `Suicidal|Depressed`: original top-3 10/10; bootstrap top-3 1.0000; remains stable: true

The ordered Phase 5 hard-pair set was not changed. Composition dependence and residual named-class structure are reported separately.
