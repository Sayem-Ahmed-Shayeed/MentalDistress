# Phase 8 All-Pair Specialist Report

## Material Passport

- Data scope: locked training and validation splits only.
- Global models: ten verified, seed-matched MentalRoBERTa checkpoints.
- Specialist bank: 10 seeds × 10 unordered pairs = 100 linear heads.
- Representation: frozen final hidden-layer token-zero (`<s>`) vector.
- Loss: class-weighted cross-entropy with `N / (2 * N_c)`.
- Execution: CUDA GPU; one encoder resident at a time; float32 inference.
- Test access: false.
- Routing: not performed; no `tau` was selected.

## Completeness

All 100 seed-pair heads passed persistence and reload verification.
Each seed contributes all ten pairs and each pair contributes all ten seeds.

## Frozen downstream routing scope

Phase 5 remains frozen at `K=3` with:
- `Frustrated|Others`
- `Suicidal|Depressed`
- `Depressed|Others`

Phase 9 may activate only those three pair types and calibrate `tau` on validation data.
Phase 8 neither routes examples nor changes the frozen hard-pair set.

## Aggregate validation summary

```text
 pair_index                 pair    class_a    class_b  seed_count  mean_validation_macro_f1  sample_sd_validation_macro_f1  min_validation_macro_f1  max_validation_macro_f1  mean_validation_accuracy  mean_balanced_accuracy  median_best_epoch
          0   Suicidal|Depressed   Suicidal  Depressed          10                  0.915994                       0.003724                 0.909578                 0.920143                  0.919145                0.914784           2.000000
          1     Suicidal|Anxious   Suicidal    Anxious          10                  0.981530                       0.002786                 0.978742                 0.985296                  0.981566                0.981409           3.000000
          2  Suicidal|Frustrated   Suicidal Frustrated          10                  0.967423                       0.006197                 0.952660                 0.973045                  0.967617                0.967064           1.000000
          3      Suicidal|Others   Suicidal     Others          10                  0.964896                       0.006897                 0.946961                 0.971203                  0.965143                0.965224           4.000000
          4    Depressed|Anxious  Depressed    Anxious          10                  0.959205                       0.011184                 0.932029                 0.972146                  0.960039                0.959952           4.500000
          5 Depressed|Frustrated  Depressed Frustrated          10                  0.959054                       0.008014                 0.944426                 0.969409                  0.959677                0.958640           3.000000
          6     Depressed|Others  Depressed     Others          10                  0.933214                       0.011354                 0.911573                 0.954555                  0.938167                0.932382           1.000000
          7   Anxious|Frustrated    Anxious Frustrated          10                  0.983169                       0.005120                 0.971907                 0.989483                  0.983187                0.983162           1.000000
          8       Anxious|Others    Anxious     Others          10                  0.960867                       0.007471                 0.944443                 0.969915                  0.961481                0.961219           1.500000
          9    Frustrated|Others Frustrated     Others          10                  0.896698                       0.008240                 0.883268                 0.907302                  0.899240                0.896930           2.000000
```

These are validation descriptions of frozen-encoder specialists, not test estimates.
