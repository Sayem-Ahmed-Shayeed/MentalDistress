# Phase 3 Freeze Report

Status: **PASS**

Completed seeds: 10

Validation Macro-F1: 0.863197843 ± 0.003566556 (sample SD)

Validation accuracy: 0.866577181 ± 0.003315192 (sample SD)

The locked test was not accessed. Model archives were intentionally not included locally.
