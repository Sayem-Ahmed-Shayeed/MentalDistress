# Phase 4 Residual Boundary Report

This report identifies **provisional criterion-1 candidates only**. No final hard pair is frozen here; Phase 5 bootstrap validation is mandatory.

## Leading observed pairs

- Frustrated|Others: mean BCR 0.093227, top-three count 10/10
- Suicidal|Depressed: mean BCR 0.078162, top-three count 10/10
- Depressed|Others: mean BCR 0.046388, top-three count 10/10

Kendall's W: 0.954424
