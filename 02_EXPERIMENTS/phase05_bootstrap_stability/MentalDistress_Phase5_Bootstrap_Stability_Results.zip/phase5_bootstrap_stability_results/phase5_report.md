# Phase 5 Bootstrap Stability Report

## Material Passport

- Data scope: frozen validation predictions from ten MentalRoBERTa training seeds.
- Statistical unit: validation row, resampled within true class separately per model seed.
- Bootstrap: 2000 replicates per seed; master seed 20260822.
- Verification: artifact integrity, original Phase 4 reproduction, row-count, finite-value, rank, and manifest gates.
- Test access: false. Model weights, raw text, GPU, and network were not used.
- Limitation: intervals describe validation-sample stability with trained predictions fixed; they do not estimate retraining or test uncertainty.

## Frozen hard-pair set H

- `Frustrated|Others`
- `Suicidal|Depressed`
- `Depressed|Others`

K = 3 (K_max = 3).

A pair required original top-3 presence in at least 7/10 seeds and mean seed-specific bootstrap top-3 frequency of at least 0.70. The pooled bootstrap intervals are descriptive only.
