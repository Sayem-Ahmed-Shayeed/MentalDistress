# Phase 12 Ten-Seed Efficiency Benchmarking Report

Status: PASS

GPU: Tesla T4
Frozen H: ['Frustrated|Others', 'Suicidal|Depressed', 'Depressed|Others']
Frozen K: 3
Frozen tau: 0.10
Phase 10 reproductions: 10/10 PASS
Test data accessed: False

## Consolidated equal-seed summary

```csv
system_id,seed_count,mean_macro_f1,sd_macro_f1,mean_routing_coverage,sd_routing_coverage,mean_added_parameters,sd_added_parameters,mean_parameter_overhead_pct_vs_A0,sd_parameter_overhead_pct_vs_A0,mean_coverage_weighted_added_macs_per_example,sd_coverage_weighted_added_macs_per_example,mean_batch1_median_latency_ms,sd_batch1_median_latency_ms,mean_batch1_median_latency_overhead_pct_vs_flat,sd_batch1_median_latency_overhead_pct_vs_flat,mean_throughput_mean_samples_per_second,sd_throughput_mean_samples_per_second,mean_throughput_change_pct_vs_flat,sd_throughput_change_pct_vs_flat,mean_peak_cuda_allocated_bytes,sd_peak_cuda_allocated_bytes,mean_peak_cuda_reserved_bytes,sd_peak_cuda_reserved_bytes
A0_flat,10,0.8631978431731311,0.0035665562828621567,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,9.774292499986359,0.027910475202964358,0.0,0.0,44.67150141413213,0.208652070453388,0.0,0.0,790622720.0,0.0,912261120.0,0.0
A1_conditional,10,0.8641379425246593,0.004308685079971002,0.0065771812080536295,0.004347188474806646,4614.0,0.0,0.0037015799111616,4.57139774554258e-19,10.102550335570468,6.677281497303037,9.911703824974438,0.026816499241928124,1.4060718544082775,0.20693304808944096,44.61730231906969,0.17602908569679862,-0.12081696123949792,0.22537746008376858,790642688.0,0.0,912261120.0,0.0
A2_always_route,10,0.8649209057993671,0.004023834260041136,0.5565771812080536,0.16279193364243938,4614.0,0.0,0.0037015799111616,4.57139774554258e-19,854.9025503355704,250.0484100747869,10.100830449994191,0.06779883119239523,3.3424943676194965,0.8865529414385884,44.507645983699895,0.16364791901915687,-0.3661717863377812,0.23833105904179414,790642688.0,0.0,912261120.0,0.0
```

## Claim guardrails

```csv
system_id,latency_speed_claim_supported_seeds,throughput_speed_claim_supported_seeds,claim_rule
A0_flat,0,0,reference system
A1_conditional,0,0,speed claim requires the paired 95% CI to support direction
A2_always_route,0,0,speed claim requires the paired 95% CI to support direction
```

Timings describe this Kaggle GPU, float32 precision, and model-side scope.
They exclude tokenization, disk I/O, transfer, and serving overhead.
A1 can reduce activated specialist compute at low routing coverage even though all three heads remain resident.
Intervals quantify repeated benchmark variation on one hardware setting.
These efficiency results do not establish deployment safety or clinical suitability.
Dataset class labels are operational labels, not clinical diagnoses.
Phase 12 cannot change H, K, tau, specialist heads, global checkpoints, or the locked-test plan.
