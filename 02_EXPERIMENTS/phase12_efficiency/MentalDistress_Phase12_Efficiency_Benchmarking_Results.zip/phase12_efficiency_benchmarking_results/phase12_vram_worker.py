
import argparse
import json
import os
from pathlib import Path

os.environ["TOKENIZERS_PARALLELISM"] = "false"
os.environ["TRANSFORMERS_VERBOSITY"] = "error"

import pandas as pd
import torch
from safetensors.torch import load_file
from transformers import AutoModelForSequenceClassification, AutoTokenizer

parser = argparse.ArgumentParser()
parser.add_argument("--seed", type=int, required=True)
parser.add_argument("--system", required=True)
parser.add_argument("--model-dir", required=True)
parser.add_argument("--phase8-root", required=True)
parser.add_argument("--validation", required=True)
parser.add_argument("--output", required=True)
args = parser.parse_args()

LABELS = ["Suicidal", "Depressed", "Anxious", "Frustrated", "Others"]
LABEL_TO_ID = {label: index for index, label in enumerate(LABELS)}
HARD_PAIRS = [
    "Frustrated|Others",
    "Suicidal|Depressed",
    "Depressed|Others",
]
TAU = {"A1_conditional": 0.10, "A2_always_route": 1.00}
DEVICE = torch.device("cuda:0")
assert args.system in ["A0_flat", "A1_conditional", "A2_always_route"]
assert torch.cuda.is_available()

def pair_slug(pair_name):
    first, second = pair_name.split("|")
    return first.lower() + "__" + second.lower()

def load_heads():
    weights, biases, class_maps = [], [], []
    for pair_name in HARD_PAIRS:
        head_dir = (
            Path(args.phase8_root)
            / "heads"
            / f"seed_{args.seed}"
            / pair_slug(pair_name)
        )
        metadata = json.loads((head_dir / "metadata.json").read_text())
        state = load_file(str(head_dir / "head.safetensors"), device="cpu")
        weights.append(state["classifier.weight"].float())
        biases.append(state["classifier.bias"].float())
        class_maps.append(
            [
                LABEL_TO_ID[metadata["class_a"]],
                LABEL_TO_ID[metadata["class_b"]],
            ]
        )
    lookup = torch.full((5, 5), -1, dtype=torch.long)
    for index, pair_name in enumerate(HARD_PAIRS):
        first, second = pair_name.split("|")
        a, b = LABEL_TO_ID[first], LABEL_TO_ID[second]
        lookup[a, b] = index
        lookup[b, a] = index
    return {
        "weights": torch.stack(weights).to(DEVICE),
        "biases": torch.stack(biases).to(DEVICE),
        "class_maps": torch.tensor(class_maps, dtype=torch.long, device=DEVICE),
        "lookup": lookup.to(DEVICE),
    }

def forward(model, heads, batch):
    with torch.inference_mode(), torch.autocast(
        device_type="cuda", enabled=False
    ):
        encoded = model.roberta(**batch, return_dict=True)
        sequence = encoded.last_hidden_state
        logits = model.classifier(sequence)
        if args.system == "A0_flat":
            return torch.argmax(logits, dim=1)
        probabilities = torch.softmax(logits, dim=1)
        values, ids = torch.topk(probabilities, 2, dim=1)
        margin = values[:, 0] - values[:, 1]
        pair_index = heads["lookup"][ids[:, 0], ids[:, 1]]
        active = (pair_index >= 0) & (margin <= TAU[args.system])
        prediction = ids[:, 0].clone()
        if int(active.sum().item()):
            selected = pair_index[active]
            features = sequence[active, 0, :].unsqueeze(2)
            pair_logits = torch.bmm(
                heads["weights"][selected], features
            ).squeeze(2)
            pair_logits = pair_logits + heads["biases"][selected]
            local = torch.argmax(pair_logits, dim=1)
            prediction[active] = heads["class_maps"][selected, local]
        return prediction

tokenizer = AutoTokenizer.from_pretrained(args.model_dir, local_files_only=True)
model = AutoModelForSequenceClassification.from_pretrained(
    args.model_dir,
    local_files_only=True,
    torch_dtype=torch.float32,
).eval().to(DEVICE)
heads = None if args.system == "A0_flat" else load_heads()
torch.cuda.synchronize()
resident_allocated = int(torch.cuda.memory_allocated())
resident_reserved = int(torch.cuda.memory_reserved())
torch.cuda.reset_peak_memory_stats()
frame = pd.read_csv(args.validation)
texts = frame["text"].astype(str).tolist()
for start in range(0, len(texts), 16):
    encoded = tokenizer(
        texts[start : start + 16],
        padding=True,
        truncation=True,
        max_length=512,
        return_tensors="pt",
    )
    batch = {name: tensor.to(DEVICE) for name, tensor in encoded.items()}
    forward(model, heads, batch)
torch.cuda.synchronize()
result = {
    "model_seed": args.seed,
    "system_id": args.system,
    "resident_cuda_allocated_bytes": resident_allocated,
    "resident_cuda_reserved_bytes": resident_reserved,
    "peak_cuda_allocated_bytes": int(torch.cuda.max_memory_allocated()),
    "peak_cuda_reserved_bytes": int(torch.cuda.max_memory_reserved()),
    "validation_rows": len(frame),
    "batch_size": 16,
    "gpu_name": torch.cuda.get_device_name(0),
}
Path(args.output).write_text(
    json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8"
)
